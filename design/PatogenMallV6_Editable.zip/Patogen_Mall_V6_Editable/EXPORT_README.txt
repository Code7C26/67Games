PATOGEN MALL V6 EDITABLE — exportación e integración

Prueba independiente:
1. Abrir project.godot con Godot 4.7 o compatible.
2. Ejecutar main.tscn para caminar con el pato placeholder.
3. Ejecutar VistaMapaCompleto.tscn con F6 para ver todo el shopping.

Edición visual:
Abrir PatogenMall_Editable.tscn. El mapa está compuesto por nodos normales y no se genera mediante scripts.

Integración con el juego del equipo:
Instanciar PatogenMall_MapOnly.tscn. No agregar una segunda copia de sus colisiones.

El jugador real debe conservar su CharacterBody2D y usar la capa de colisión 1, o bien se deben ajustar en el Inspector las capas de los StaticBody2D del mapa.

Las zonas HOT/COLD, entradas, marcadores de navegación y spawns de huéspedes se identifican mediante grupos. Consultar MAP_INTEGRATION.md.


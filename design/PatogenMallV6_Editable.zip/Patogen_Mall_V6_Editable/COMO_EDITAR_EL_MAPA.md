# PATOGEN MALL V6 — mapa editable desde Godot

El mapa ya no se dibuja por código. Todo lo que ves en pantalla existe como nodos normales dentro de:

`PatogenMall_Editable.tscn`

## Abrirlo y verlo completo

1. Importá `project.godot` desde el Project Manager de Godot.
2. En **FileSystem**, hacé doble clic en `PatogenMall_Editable.tscn`.
3. Entrá a la vista **2D**.
4. Presioná **F** para encuadrar todo el shopping si no aparece completo.

## Qué podés modificar sin tocar código

En el árbol de la escena vas a encontrar:

- `01_Pisos_y_Pasillos`: base visual, galerías y avenida central.
- `02_Locales`: todos los locales. Mové el nodo padre de un local para trasladar juntos su piso, cartel, puerta y colisiones.
- `03_Arquitectura`: entradas, paredes exteriores, fuente, mezzanine y escaleras.
- `04_Mobiliario`: bancos, maceteros y kioscos. Cada objeto es movible por separado.
- `05_Zonas_Gameplay`: áreas HOT/COLD. Son `Area2D` reales y tienen su forma de detección como hija.
- `06_Marcadores_IA`: cruces de navegación, spawn del pato y lugares sugeridos para huéspedes.

Para mover algo, seleccionalo y usá la herramienta **Mover (W)**. También podés escribir la posición exacta en **Inspector > Transform > Position**.

## Regla importante para no desalinear colisiones

Mové siempre el nodo padre del objeto. Por ejemplo, mové `02_Locales/Cine`, no solamente su hijo `Piso`. Así la puerta y todas las colisiones se trasladan juntas.

Si querés cambiar el tamaño de un local, editá tanto sus `Polygon2D` visuales como los `CollisionShape2D` dentro de `Colisiones`. Godot muestra las formas directamente en la vista 2D.

## Escenas para usar

- Para editar el shopping: `PatogenMall_Editable.tscn`.
- Para probarlo caminando con el pato placeholder: `main.tscn` o el botón **Play**.
- Para ver todo el mapa con una cámara fija: `VistaMapaCompleto.tscn` y **Play Current Scene (F6)**.
- Para integrarlo al juego del equipo: `PatogenMall_MapOnly.tscn`.

## Datos listos para el gameplay de Patogen

- Las zonas de temperatura pertenecen al grupo `patogen_condition_zone` y conservan `zone_type` e `intensity` en Metadata.
- Los puntos de aparición de posibles huéspedes pertenecen al grupo `host_spawn`.
- Los puntos de circulación pertenecen al grupo `patogen_navigation`.
- Las entradas pertenecen al grupo `mall_entrance`.
- Las colisiones del mapa usan la capa 1 y pertenecen al grupo `map_collision`.

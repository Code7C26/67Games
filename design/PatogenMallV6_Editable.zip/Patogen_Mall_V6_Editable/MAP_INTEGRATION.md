# PATOGEN MALL V6 — integración

La escena recomendada para integrar el mapa en el proyecto principal es:

`res://PatogenMall_MapOnly.tscn`

Esa escena contiene el mismo mapa visual y editable de `PatogenMall_Editable.tscn`, sin jugador ni HUD.

## Contrato de gameplay

- Colisiones físicas: capa 1 y grupo `map_collision`.
- Zonas de condición: grupo `patogen_condition_zone`.
- Cada zona expone Metadata: `zone_id`, `zone_type` (`hot` o `cold`) e `intensity`.
- Posibles apariciones de huéspedes: grupo `host_spawn`.
- Puntos estables de circulación: grupo `patogen_navigation`.
- Entradas del shopping: grupo `mall_entrance`.

## Edición

Para cambiar el layout no se modifica ningún script. Abrí `PatogenMall_Editable.tscn` y mové los nodos padre desde la vista 2D. La guía completa está en `COMO_EDITAR_EL_MAPA.md`.


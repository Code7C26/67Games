from pathlib import Path
import zipfile, json
from PIL import Image, ImageDraw, ImageFont
root=Path(__file__).resolve().parents[1]
workspace=root.parents[1]
validation=json.loads((root/'tests/validation.json').read_text(encoding='utf8'))
assert validation['passed'], validation['failures']
ases=list((root/'splash/assets').glob('*.aseprite'))
for ase in ases:assert ase.with_suffix('.png').exists(),ase
# Detail view for reviewing the map inflatable and the new small building.
preview=Image.new('RGB',(1280,690),'#162e3b');d=ImageDraw.Draw(preview)
font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',23)
small=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',17)
d.text((28,22),'PATO SPLASH / REVISION DE ASSETS',font=font,fill='#fff0cc')
duck=Image.open(root/'splash/assets/pato_gigante.png').convert('RGBA').crop((0,0,160,144)).resize((480,432),Image.Resampling.NEAREST)
preview.paste(duck,(32,109),duck)
building=Image.open(root/'splash/assets/vestuarios.png').convert('RGBA').crop((0,0,416,144)).resize((624,216),Image.Resampling.NEAREST)
preview.paste(building,(608,196),building)
d.text((44,576),'INFLABLE DE LA PILETA',font=font,fill='#f6cb5c')
d.text((44,612),'Contorno escalonado / ala angular / costuras',font=small,fill='#b5ced5')
d.text((608,480),'VESTUARIOS + LOCKERS',font=font,fill='#f6cb5c')
d.text((608,518),'Tres cabinas / puertas saloon / madera',font=small,fill='#b5ced5')
preview.save(root/'captures/08_detalle_revision.png')
destination=workspace/'outputs/Patogen_Pato_Splash.zip';destination.parent.mkdir(exist_ok=True)
included=[]
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for file in root.rglob('*'):
  if not file.is_file():continue
  rel=file.relative_to(root)
  if any(part in {'.godot','.runtime','frames','antes_revision','__pycache__'} for part in rel.parts):continue
  if file.suffix in {'.import','.tmp'}:continue
  if file.name in {'import.log','pato_original_ampliado.png'}:continue
  if rel.parts[0] not in {'project.godot','LEEME.md','.gitignore','splash','demo','tools','tests','docs','captures'}:continue
  z.write(file,Path('Patogen_Pato_Splash')/rel);included.append(str(rel))
with zipfile.ZipFile(destination) as z:assert z.testzip() is None
print(json.dumps({'zip':str(destination),'bytes':destination.stat().st_size,'files':len(included),'aseprite_sources':len(ases),'validation_passed':True},ensure_ascii=False))

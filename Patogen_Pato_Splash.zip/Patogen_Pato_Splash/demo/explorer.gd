extends CharacterBody2D
var player := 1
var sprite: AnimatedSprite2D
func _ready() -> void:
	collision_layer=4;collision_mask=1
	var c:=CollisionShape2D.new();var sh:=CircleShape2D.new();sh.radius=15.6;c.shape=sh;add_child(c)
	sprite=AnimatedSprite2D.new();sprite.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	var sf:=SpriteFrames.new();sf.remove_animation("default")
	for dir in ["Abajo","Arriba","Derecha","Izquierda"]:
		sf.add_animation(dir);sf.set_animation_speed(dir,8)
		var tex=load("res://demo/references/pato_"+dir.to_lower()+".png")
		for f in 8:
			var a:=AtlasTexture.new();a.atlas=tex;a.region=Rect2(f%4*32,floori(float(f)/4.0)*32,32,32);sf.add_frame(dir,a)
	sprite.sprite_frames=sf;sprite.animation="Abajo";add_child(sprite)
	queue_redraw()
func _draw() -> void:
	draw_arc(Vector2(0,8),20,0,TAU,32,Color("77e0e8") if player==1 else Color("df8bd0"),2)
func _physics_process(_delta: float) -> void:
	var d:=Vector2.ZERO
	if player==1:
		d=Vector2(float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A)),float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W)))
	else:
		d=Vector2(float(Input.is_physical_key_pressed(KEY_RIGHT))-float(Input.is_physical_key_pressed(KEY_LEFT)),float(Input.is_physical_key_pressed(KEY_DOWN))-float(Input.is_physical_key_pressed(KEY_UP)))
	velocity=d.normalized()*240
	move_and_slide()
	if d.length_squared()<.01:sprite.stop();return
	var anim:="Derecha" if d.x>0 else "Izquierda"
	if absf(d.y)>absf(d.x):anim="Abajo" if d.y>0 else "Arriba"
	sprite.play(anim)

extends Node2D
## Neutral event controller. Never changes collisions, infections, teams or scores.
signal phase_changed(phase: String, seconds_left: float)
signal attraction_requested(destinations: Array[Vector2], max_visitors: int, duration: float)
signal attraction_finished
signal splash_impact(strength: float)

@export var enabled := true
@export var calm_seconds := 30.0
@export var warning_seconds := 8.0
@export var splash_seconds := 2.0
@export var settle_seconds := 10.0
@export_range(0, 12, 1) var max_attracted_visitors := 10
@export var audio_enabled := true
var phase := "calma"
var elapsed := 0.0
var cycles := 0
var paused := false
var bucket: Node2D
var fx: Node2D
var chime: AudioStreamPlayer
var impact_sound: AudioStreamPlayer

func _ready() -> void:
	bucket = get_node("04_Objetos/Balde")
	fx = get_node("05_Efectos")
	chime = AudioStreamPlayer.new()
	chime.stream = preload("res://splash/assets/aviso.wav")
	chime.volume_db = -8
	add_child(chime)
	impact_sound = AudioStreamPlayer.new()
	impact_sound.stream = preload("res://splash/assets/chapuzon.wav")
	impact_sound.volume_db = -10
	add_child(impact_sound)
	fx.visible = false

func phase_duration() -> float:
	match phase:
		"aviso": return maxf(.1, warning_seconds)
		"chapuzon": return maxf(.1, splash_seconds)
		"reposo": return maxf(.1, settle_seconds)
	return maxf(.1, calm_seconds)

func _process(delta: float) -> void:
	if not enabled or paused: return
	advance_event(delta)

func advance_event(delta: float) -> void:
	elapsed += delta
	while elapsed >= phase_duration():
		elapsed -= phase_duration()
		match phase:
			"calma":
				phase = "aviso"
				var destinations: Array[Vector2] = []
				for marker_name in ["ChapuzonOeste", "ChapuzonCentro", "ChapuzonEste"]:
					destinations.append(get_node("06_Marcadores/"+marker_name).global_position)
				attraction_requested.emit(destinations,max_attracted_visitors,warning_seconds+splash_seconds+settle_seconds)
				if audio_enabled: chime.play()
			"aviso":
				phase = "chapuzon"
				splash_impact.emit(1.0)
				if audio_enabled: impact_sound.play()
			"chapuzon": phase = "reposo"
			"reposo":
				phase = "calma"
				cycles += 1
				attraction_finished.emit()
	phase_changed.emit(phase,maxf(0,phase_duration()-elapsed))
	_update_effects()

func _update_effects() -> void:
	if not is_instance_valid(bucket): return
	var angle := 0.0
	if phase == "aviso": angle = sin(elapsed*5.0)*.025*(elapsed/warning_seconds)
	elif phase == "chapuzon": angle = sin(clampf(elapsed/splash_seconds,0,1)*PI)*1.1
	bucket.get_node("Textura").rotation = angle
	fx.visible = phase == "chapuzon"
	if fx.visible:
		var t := elapsed/splash_seconds
		fx.modulate.a = minf(1.0,(1.0-t)*2.4)
		fx.get_node("Chorro").frame=mini(11,int(t*12))

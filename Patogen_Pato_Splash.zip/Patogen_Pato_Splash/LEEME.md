# Patogen · Pato Splash

Primera versión explorable del parque acuático, creada con los MCP de **Aseprite y Godot**. Agua celeste, geometría estable y un único evento principal: el gran chapuzón.

## Abrir

Importar `project.godot` en Godot 4.7.1 y pulsar **F5**. La escena inicial es `demo/PatoSplashDemo.tscn`. El mapa editable es `splash/scenes/PatoSplash.tscn`.

- **WASD / flechas:** recorrer el parque con los dos patos.
- **E** o botón «Ver chapuzón»: adelantar el comienzo del aviso; conserva los ocho segundos de anticipación.
- **Espacio:** pausar/reanudar todo el parque.
- **Tab:** catálogo animado de NPC; pausa el parque mientras está abierto.
- **R:** activar/desactivar la vibración de cámara.
- **M:** activar/desactivar el sonido.
- **H:** mostrar/ocultar interfaz.
- **F11:** pantalla completa. **Esc:** cerrar catálogo o salir de pantalla completa.

## Contenido

- Cuatro piletas de agua celeste; pato inflable gigante, toboganes dobles, balde, fuente hongo y flotadores.
- Reposeras, sombrillas, heladería, vestuarios en una construcción baja con tres cabinas de puertas dobles de madera tipo saloon y lockers empotrados, sillas de salvavidas, palmeras, banderines, filtros, mesas, bancos y papeleras. Duchas y casilleros independientes también incluidos como assets reutilizables.
- **55 objetos colocados**, además de las piletas, los pisos y la señalética. Escenas de objetos reutilizables en `splash/scenes/objetos`.
- Agua, pato, toboganes, sombrillas, palmeras, toldo, duchas, flotadores, banderines, ventiladores, fuente y descarga animados. El balde gira al descargar.
- **9 skins de NPC:** 3 bañadores, 3 salvavidas y 3 staff. Cada una conserva las cuatro direcciones y los 12 cuadros de marcha originales: **108 cuadros adaptados**. Cabezas y siluetas originales preservadas.
- Fuentes **`.aseprite`**, hojas **PNG**, metadatos **JSON** y recursos **SpriteFrames `.tres`**.
- Revisión artística: pato inflable de la pileta redibujado con contornos escalonados, pico ancho y ala angular; material de madera, tela, metal y cerámica en capas separadas. Los patos controlables mantienen sus sprites originales.
- Demo con **54 visitantes**, dos patos controlables y audio original sintetizado para agua, aviso y descarga.

## Evento

El ciclo normal dura **50 segundos**: 30 de calma, 8 de aviso, 2 de descarga y 10 de reposo. Primer impacto a los 38 segundos. Todo el mapa permanece visible; la sacudida dura 0,55 s y alcanza como máximo 2,2 px por eje. Se puede desactivar.

En la demo se invita a un máximo de diez bañistas próximos, hasta cinco de cada lado. Se desplazan por rutas normales y vuelven a circular al terminar. La selección usa posición y distancia, sin consultar colores de equipo ni infección. Los caminos y las colisiones permanecen fijos. El evento no modifica contagios, curación, recursos ni puntuación.

## Alcance

Esta entrega es el **mapa y su demo de circulación**, con el controlador de evento listo para conectar. **No incorpora una partida completa con infección, mutaciones o robots de Patogen.** Los nueve aspectos son skins sanas; las transformaciones infectadas siguen perteneciendo al juego principal.

La igualdad de distancia al evento y las pruebas de navegación son comprobaciones geométricas, no una certificación de balance competitivo. La integración con la IA real y las habilidades debe probarse en partidas.

La construcción de vestuarios es una fachada sólida en esta primera versión; sus puertas animadas son ambientales. No incluye interiores transitables.

Ver `docs/INTEGRACION.md` y `docs/VALIDACION.md`. Las capturas están en `captures`.

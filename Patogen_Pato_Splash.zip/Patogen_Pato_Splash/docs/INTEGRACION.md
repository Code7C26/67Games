# Integración en Patogen

## Mapa y cámara

1. Copiar **`splash` completa** al proyecto de mecánicas, manteniendo sus rutas `res://splash/...`.
2. Instanciar `res://splash/scenes/PatoSplash.tscn` en **(0,0), escala (1,1)** como entorno de una nueva escena de partida. Mantener los controladores, patos, bots y HUD reales.
3. El lienzo es **1920 × 1080**. El mapa ocupa `Rect2(32,112,1856,860)`, disponible como metadata `play_rect`; usar esa región para la cámara/HUD. El encabezado de la demo termina en y=96 y el pie comienza en y=992.
4. Los obstáculos usan **capa física 1, máscara 0**. Confirmar que los cuerpos reales consultan capa 1. El agua es un obstáculo: esta primera versión se recorre por las veredas, no incluye natación.
5. Leer los marcadores `06_Marcadores/InicioPato_A` **(592,744)** y `InicioPato_B` **(1328,744)**. Los dos tienen una ruta de 736 px al marcador central del evento en la cuadrícula de prueba.
6. Los objetos usan origen inferior y el contenedor `04_Objetos` tiene `y_sort_enabled`. Colocar los actores en el mismo orden por Y o reproducirlo en el contenedor real. El balde tiene su origen visual en el centro para permitir el giro.

Los pisos son un `TileMapLayer` de 32 px; piletas, señales, objetos y marcadores son nodos editables. Las instancias de objetos permiten editar sus hijos; sus colisiones se guardan en la escena. No regenerar encima de una versión editada manualmente sin conservar una copia.

## NPC

Asignar en las skins sanas del Bot real uno de los recursos:

- `res://splash/assets/banador_1.tres` a `banador_3.tres`.
- `res://splash/assets/salvavidas_1.tres` a `salvavidas_3.tres`.
- `res://splash/assets/staff_1.tres` a `staff_3.tres`.

Animaciones **Abajo / Arriba / Derecha / Izquierda**, 2/2/4/4 cuadros, **5 FPS**, celdas de **32 × 32**. Se preservan los píxeles de las cabezas y el canal alfa original. No hace falta cambiar tamaño ni colisión para vestirlos. En Aseprite hay una capa original conservada y una capa separada de vestuario.

Las referencias provienen de las hojas NPC 1, 2 y 3 ya disponibles en la entrega local del laboratorio. Sus hashes están en `referencias_sha256.json`. Los patos de exploración son copias de las hojas ya existentes en la entrega de introducción. Ningún original fue modificado.

## Evento y conexión con la IA

El script de la raíz `splash/scripts/splash_event.gd` expone:

```gdscript
signal phase_changed(phase: String, seconds_left: float)
signal attraction_requested(destinations: Array[Vector2], max_visitors: int, duration: float)
signal attraction_finished
signal splash_impact(strength: float)
```

- `phase_changed`: mostrar el estado y el aviso para ambos jugadores en el HUD real.
- `attraction_requested`: pedir a un conjunto limitado de bots que camine hacia los tres marcadores del mirador usando **la navegación real**. No reposicionarlos ni sobrescribir su equipo, cepa o estado de infección. La demo usa hasta cinco bañistas próximos de cada lado, con criterio de distancia.
- `attraction_finished`: liberar la intención temporal de visita y devolverlos a su comportamiento normal.
- `splash_impact`: conectar a una vibración breve de la cámara común, dejando intacto el HUD. Respetar la preferencia de movimiento reducido.

El mapa emite esas señales, pero **no dirige automáticamente el `Bot.gd` real**. `demo/visitor.gd` y `demo/routes.gd` son adaptadores de demostración, no sustitutos de esa IA. Antes de integrar, añadir una intención temporal de destino al controlador real respetando posesión, persecución y otras prioridades existentes.

Activar `enabled` cuando comienza la fase de partida correspondiente; desactivarlo al terminar. El reloj debe pausarse junto con la simulación. `audio_enabled` controla los sonidos del evento; la ambientación continua está en la demo y puede conectarse al AudioManager real.

Los roles salvavidas/staff son sólo apariencia en esta entrega. No curan, conceden recursos ni tienen inmunidad. La distribución de población y el impacto de la concentración temporal requieren pruebas de balance con las tres cepas.

## Regeneración

1. Aseprite: `--batch --script-param base=<ruta-absoluta-del-proyecto-con-barra-final> --script tools/build_art.lua`.
2. Python con Pillow: `tools/prepare.py` prepara el layout, sonido y hojas de contacto.
3. Importar los assets en Godot; ejecutar `--headless --path <proyecto> --script tools/build_scene.gd`.
4. Ejecutar las pruebas descritas en `VALIDACION.md`.

Los generadores sobrescriben los archivos generados de esta entrega. Su uso es opcional: las fuentes Aseprite, las escenas y los recursos pueden editarse directamente.

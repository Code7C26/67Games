# Patogen · Laboratorio AV-07

Proyecto independiente del shopping, creado con los MCP de Aseprite y Godot. Diseño y capturas a **1920 × 1080**, con el laboratorio completo visible y bandas reservadas para el HUD actualizado. Entrega del 23 de octubre de 2026.

## Abrir y explorar

1. Importar `project.godot` en **Godot 4.7.1** y pulsar F6 sobre `demo/VistaLaboratorio.tscn`, o F5.
2. **F11**: pantalla completa. **H**: mostrar/ocultar HUD. **N**: mostrar/ocultar científicos. **Espacio**: detener/reanudar la caminata de la demo. **F2**: catálogo. **Esc/F2**: volver del catálogo.
3. Para editar el mapa, abrir **`lab/scenes/Laboratorio.tscn`**. No depende del shopping ni de los scripts de infección.

La ventana inicial es de 1440 × 810 para poder revisarla cómodamente; el lienzo de diseño y las capturas son siempre de 1920 × 1080. F11 permite revisar a tamaño de pantalla.

## Contenido

- Siete sectores: genómica, cultivo, criogenia, descontaminación, control, síntesis y logística.
- Seis cápsulas con patos infectados suspendidos, reflejos, flotación y burbujas.
- Biorreactores, telemetría y sintetizadores animados. Animaciones de ocho cuadros, desfasadas entre equipos.
- 18 objetos modulares, con escenas individuales, colisiones y fuentes Aseprite.
- Atlas de pisos y paredes de 256 × 128; celdas de 32 × 32. Los muebles y personajes tienen recursos separados.
- Tres científicos adaptados de los **NPC 1, 2 y 3 reales** de `Desktop/proyecto`. Conservan cabezas, siluetas y fotogramas originales; batas y credenciales están en una capa aparte.
- Demo de circulación con 36 científicos, sin sistemas de infección. El HUD usa una copia del diseño actualizado, con valores de muestra.

## Archivos de uso directo

| Recurso | Ruta |
|---|---|
| Mapa independiente | `lab/scenes/Laboratorio.tscn` |
| Objetos reutilizables | `lab/scenes/objetos/` |
| Catálogo visual | `demo/Catalogo.tscn` |
| Arte editable y exportaciones | `lab/assets/` |
| Skins compatibles con Bot | `lab/assets/cientifico_1.tres`, `cientifico_2.tres`, `cientifico_3.tres` |
| Vista con HUD y científicos | `captures/01_laboratorio_hud_1920x1080.png` |
| Vista sin HUD ni personajes | `captures/02_laboratorio_limpio_1920x1080.png` |
| NPC antes/después | `captures/04_cientificos_antes_despues.png` |
| Vista animada | `captures/05_laboratorio_animado.gif` |
| Integración | `docs/INTEGRACION.md` |
| Pruebas y límites | `docs/VALIDACION.md` y `tests/validation.json` |

Los rótulos, pisos, paredes, objetos y marcadores se editan por separado. Las áreas de color son ambientación: no activan frío, calor, infección ni curación.

El proyecto del shopping y `Desktop/proyecto` se consultaron como referencia y no fueron modificados por esta entrega.

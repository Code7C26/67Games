from pathlib import Path
import hashlib, json, struct, zipfile

root=Path(__file__).resolve().parents[1]
report=json.loads((root/'tests/validation.json').read_text(encoding='utf-8'))
assert not report['failures'],report['failures']
for name in ['01_laboratorio_hud_1920x1080.png','02_laboratorio_limpio_1920x1080.png','03_catalogo_1920x1080.png']:
    data=(root/'captures'/name).read_bytes()
    assert struct.unpack('>II',data[16:24])==(1920,1080)
manifest={}
for p in sorted((root/'demo/referencias_originales').glob('*.png')):
    manifest[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'docs/referencias_sha256.json').write_text(json.dumps({'source':'C:/Users/feliv/OneDrive/Desktop/proyecto/assets','files':manifest},indent=2),encoding='utf8')
summary=f'''# Verificación · 23 de octubre de 2026

Godot 4.7.1 y Aseprite 1.3.17, utilizados por sus MCP. Capturas tomadas desde Godot y revisadas a 1920 × 1080.

## Resultados

- **{report['connected_destination_pairs']} pares de destinos conectados**, incluyendo recorridos de vuelta.
- **{report['alternate_entrance_checks']} comprobaciones de acceso alternativo**: se cerró de a una cada entrada principal y se verificó que todos los sectores siguieran conectados.
- **{report['connected_pairs_at_72px_clearance']} pares conectados con un margen de 36 px**, equivalente a espacio geométrico para un cuerpo de 72 px. Esta prueba de geometría no representa una simulación de robots reales.
- **HUD sin intersección** con el área completa del mapa.
- **36 actores durante 120 segundos simulados**, cápsulas de radio 11.5 y altura 32 como el Bot local consultado. Colisión sólida con el entorno; separación suave entre actores, que pueden solaparse si coinciden. No se validan colisiones físicas entre los NPC reales.
- Recorrido mínimo por actor: **{report['simulation']['minimum_distance_px']} px**. Rutas terminadas: **{report['simulation']['completed_routes']}**. Actores inactivos: **{len(report['simulation']['inactive_actors'])}**.
- Muestras con penetraciones de paredes superiores a la tolerancia de 0.25 px: **{report['simulation']['wall_penetration_samples']}**. Muestreo cada dos segundos.
- La demo usó **{report['simulation']['route_recoveries']} cambios de destino por bloqueos momentáneos**; el mayor bloqueo registrado fue de **{report['simulation']['max_blocked_seconds']} s**. No se afirma ausencia de todo contacto o congestión. Los actores de prueba se separan al cruzarse y replantean sus recorridos.
- Científicos: **36 fotogramas originales adaptados**, 36.864 píxeles comparados; **cero cambios en cabezas y transparencia/silueta**. Batas en una capa separada. Mismas cantidades y orden de cuadros por dirección que los NPC originales.
- Atlas, 18 objetos modulares y científicos con PNG y fuente `.aseprite`. Cinco tipos de equipos con ciclos de ocho cuadros; los científicos conservan sus cuatro caminatas.
- Tres capturas verificadas de 1920 × 1080 y un GIF de 24 cuadros capturado en Godot.
- La ejecución final de la prueba terminó sin fallos, errores de script ni avisos de recursos filtrados. Resultados completos en `tests/validation.json`.

## Alcance real

La circulación se verificó con actores de demostración y la geometría del laboratorio. La entrega no incorpora los sistemas de infección, posesión, temperatura ni teletransporte del juego. La IA reactiva del `Bot.gd` real no es la navegación de la demo: antes de publicar el nivel hay que probar partidas completas con sus NPC, habilidades, poblaciones y robots reales. Las posiciones iniciales son propuestas comparables, no balance competitivo medido.

## Repetir

`Godot --headless --path <carpeta> --fixed-fps 60 --script tests/validate.gd`

`Godot --path <carpeta> tests/Capture.tscn`

Las pruebas no requieren modificar el shopping ni el proyecto de mecánicas. Los SHA256 de las 12 hojas originales están en `docs/referencias_sha256.json`.
'''
(root/'docs/VALIDACION.md').write_text(summary,encoding='utf8')
dest=root.parent/'Patogen_Laboratorio_AV07.zip'
skip_parts={'.godot','.runtime','__pycache__','frames'}
skip_captures={'art_contact.png','npc_originales.png','npc_referencia_ampliado.png'}
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for p in sorted(root.rglob('*')):
        if not p.is_file() or set(p.relative_to(root).parts)&skip_parts:continue
        if p.suffix in {'.import','.tmp'} or p.name in skip_captures:continue
        z.write(p,Path('Patogen_Laboratorio_AV07')/p.relative_to(root))
print('PACKAGE_OK',dest,'bytes=',dest.stat().st_size)
print('VALIDATION',json.dumps(report))

-- All raster assets are drawn/exported by Aseprite, without antialiasing.
local base=LAB_BASE
local out=base..'lab/assets/'
local pc=app.pixelColor
local C={}
local function col(s) if C[s] then return C[s] end local v=tonumber(s,16); local c=pc.rgba((v>>16)&255,(v>>8)&255,v&255,255);C[s]=c;return c end
local S,I,L
local ink='293b4b';local dark='405566';local steel='718b98';local mid='a7bdc5';local light='dce6df';local white='f4f5e7';local cyan='7ddbd5';local blue='377d91';local green='a9d38d';local amber='e8ba6c'
local function px(x,y,c) x=math.floor(x);y=math.floor(y);if x>=0 and y>=0 and x<I.width and y<I.height then I:drawPixel(x,y,type(c)=='string' and col(c) or c) end end
local function rect(x,y,w,h,c) for yy=y,y+h-1 do for xx=x,x+w-1 do px(xx,yy,c) end end end
local function line(x1,y1,x2,y2,c) local n=math.max(math.abs(x2-x1),math.abs(y2-y1));if n==0 then px(x1,y1,c);return end for k=0,n do px(math.floor(x1+(x2-x1)*k/n+0.5),math.floor(y1+(y2-y1)*k/n+0.5),c) end end
local function box(x,y,w,h,c)rect(x,y,w,1,c);rect(x,y+h-1,w,1,c);rect(x,y,1,h,c);rect(x+w-1,y,1,h,c) end
local function ell(x,y,w,h,c) for yy=0,h-1 do for xx=0,w-1 do if ((xx-(w-1)/2)/(w/2))^2+((yy-(h-1)/2)/(h/2))^2<=1 then px(x+xx,y+yy,c) end end end end
local function poly(points,c) local ymin,ymax=10000,-10000;for _,p in ipairs(points) do ymin=math.min(ymin,p[2]);ymax=math.max(ymax,p[2]) end;for y=ymin,ymax do local hits={};for n=1,#points do local a,b=points[n],points[n%#points+1];if (a[2]<=y and b[2]>y) or (b[2]<=y and a[2]>y) then table.insert(hits,a[1]+(y-a[2])*(b[1]-a[1])/(b[2]-a[2])) end end;table.sort(hits);for n=1,#hits-1,2 do rect(math.ceil(hits[n]),y,math.floor(hits[n+1])-math.ceil(hits[n])+1,1,c) end end end
local function layer(name,frame) L=S:newLayer();L.name=name;I=Image(S.width,S.height,ColorMode.RGB);S:newCel(L,frame or 1,I,Point(0,0));return L end
local function new(w,h)S=Sprite(w,h,ColorMode.RGB);S:deleteLayer(S.layers[1]) end
local function commit() L:cel(app.activeFrame or 1) end
local function save(name,frames)
 S:saveAs(out..name..'.aseprite');app.activeSprite=S
 if frames then app.command.ExportSpriteSheet{ui=false,type=SpriteSheetType.HORIZONTAL,textureFilename=out..name..'.png',dataFilename=out..name..'.json',dataFormat=SpriteSheetDataFormat.JSON_ARRAY,listTags=true,listLayers=true}
 else S:saveCopyAs(out..name..'.png') end
 print(name..' '..S.width..'x'..S.height..' frames='..#S.frames);S:close()
end
local function flush(frame) S:newCel(L,frame or 1,I,Point(0,0)) end
local function panel(x,y,w,h,face)
 rect(x+4,y+h-2,w-2,6,'92a8aa');rect(x,y,w,h,ink);rect(x+2,y+2,w-4,h-4,mid);rect(x+3,y+3,w-6,3,white);rect(x+4,y+6,w-8,h-11,face or light);rect(x+3,y+h-8,w-6,5,steel);rect(x+5,y+h-7,w-10,1,mid)
end
local function screen(x,y,w,h,frame,tint)
 rect(x,y,w,h,ink);rect(x+2,y+2,w-4,h-4,'204954');rect(x+3,y+3,w-6,1,blue)
 local t=tint or cyan
 for k=0,math.floor((w-10)/6) do local hh=3+(k*7+(frame or 0)*3)%math.max(4,h-8);rect(x+5+k*6,y+h-4-hh,3,hh,t) end
 px(x+w-4,y+h-3,white)
end
local function screws(x,y,w,h) for _,a in ipairs({{x,y},{x+w-1,y},{x,y+h-1},{x+w-1,y+h-1}}) do px(a[1],a[2],white) end end
local digits={'111101101101111','010110010010111','111001111100111','111001111001111','101101111001001','111100111001111','111100111101111','111001010010010','111101111101111','111101111001111'}
local function num(n,x,y,c)for _,v in ipairs({math.floor(n/10),n%10}) do local g=digits[v+1];for p=1,15 do if g:sub(p,p)=='1' then px(x+(p-1)%3,y+math.floor((p-1)/3),c) end end;x=x+4 end end

-- Modular atlas: floor materials and their discreet variations; walls only in last row.
new(256,128);layer('Pisos y paredes - 32px')
local floors={{'c5d2d0','b0c1c1','dce5df'},{'bdc6d4','a8b3c5','d1dbe2'},{'b6cdb9','9fb9a7','d1dfc9'},{'afcbd0','95b7c1','cedfe0'},{'cfc5bd','b6a9a4','e0d7cd'},{'afc1ce','98adbf','c9d8df'},{'d1c8aa','b7ad92','e4ddc1'},{'bdc6c4','a4b0b1','d5ded7'}}
for j=0,2 do for k=0,7 do local x,y=k*32,j*32;local f=floors[k+1];rect(x,y,32,32,f[1]);rect(x,y,32,1,f[2]);rect(x,y,1,32,f[2]);line(x+1,y+1,x+31,y+1,f[3]);line(x+1,y+1,x+1,y+31,f[3]);if j==1 then line(x+5,y+26,x+14,y+26,f[3]);line(x+5,y+27,x+9,y+27,f[3]) elseif j==2 then for p=5,26,7 do px(x+p,y+5,f[3]) end;rect(x+24,y+24,4,4,f[2]);rect(x+25,y+25,2,2,f[3]) end end end
for k=0,7 do local x=k*32;rect(x,96,32,32,'8c9fa4');rect(x,96,32,3,ink);rect(x,99,32,11,light);rect(x+1,100,30,2,white);rect(x,110,32,2,steel);rect(x,112,32,11,dark);rect(x,123,32,3,ink);rect(x,126,32,2,'94a6a7');rect(x+3,115,26,1,steel);if k%2==1 then rect(x+5,117,22,2,cyan) end;line(x+31,99,x+31,109,mid) end
flush();save('laboratorio_tiles')

-- Cryogenic capsule. The suspended specimen uses Patogen's October duck artwork.
local duck=Image{fromFile=base..'demo/pato_referencia.png'}
new(96,144);layer('Capsula - estructura')
ell(6,125,84,17,'93aaad');rect(10,20,76,101,ink);rect(12,20,72,100,steel);rect(17,24,62,91,'316776');rect(20,25,56,87,'438492');rect(23,27,49,84,'62a3a5');rect(29,30,37,80,'70b5b1');ell(17,15,62,24,mid);ell(18,15,60,16,light);ell(24,18,48,9,steel);rect(11,22,9,94,dark);rect(12,25,3,87,cyan);rect(77,22,8,94,dark);rect(80,27,2,84,light);rect(8,109,80,25,ink);rect(10,111,76,20,steel);rect(13,111,70,4,light);rect(14,116,18,11,dark);rect(65,117,16,6,ink);rect(68,119,10,2,green);rect(37,119,20,7,ink);rect(40,121,14,2,cyan);ell(8,4,80,24,ink);ell(10,5,76,20,mid);ell(14,6,68,12,light);rect(27,8,42,4,white);rect(39,20,18,4,dark);screws(13,116,69,14);flush()
local structure=L
for f=1,8 do if f>1 then S:newEmptyFrame() ;S:newCel(structure,f,structure:cel(1).image,Point(0,0)) end end
L=S:newLayer();L.name='Pato infectado - suspendido'
for f=1,8 do I=Image(96,144,ColorMode.RGB);local by=40+math.floor(math.sin((f-1)*math.pi/4)*2)
 for y=0,31 do for x=0,31 do local p=duck:getPixel(x,y);if pc.rgbaA(p)>0 then local r,g,b=pc.rgbaR(p),pc.rgbaG(p),pc.rgbaB(p);local c=pc.rgba(math.floor(r*.69),math.min(255,math.floor(g*.88+27)),math.min(255,math.floor(b*.63+48)),255);rect(16+x*2,by+y*2,2,2,c) end end end
 -- Small warm pathogen nodes contrast with the fluid, remaining readable at native scale.
 ell(31,by+43,6,6,'ac6970');ell(55,by+36,5,5,'bf777a');px(32,by+44,'e4a7a1');flush(f)
end
L=S:newLayer();L.name='Cristal - reflejos - burbujas'
for f=1,8 do I=Image(96,144,ColorMode.RGB);rect(22,35,3,63,'a5e0d4');rect(26,39,1,24,'b7e9db');rect(69,48,2,55,'88c8c0');line(25,91,36,80,'90cdc5');line(27,93,37,83,'90cdc5');for k=0,5 do local x=28+(k*13)%39;local y=32+(k*17-f*4)%70;box(x,y,3,3,'b2eee1') end;rect(65,119,13,3,f%4<2 and cyan or green);flush(f) end
local tag=S:newTag(1,8);tag.name='Criostasis';for _,f in ipairs(S.frames)do f.duration=.16 end;save('capsula_pato',true)

-- Scientific benches with identifiable glassware, microscope and sample racks.
local function bench(name,variant)
 new(128,72);layer('Estructura');panel(2,10,124,54,light);rect(9,19,110,32,'dce3d4');rect(8,55,112,6,mid);for x=12,106,31 do box(x,56,25,5,steel);rect(x+8,57,8,1,white) end;flush();layer('Instrumentos')
 if variant=='microscope' then
  ell(17,38,31,14,dark);ell(19,38,27,9,steel);poly({{23,39},{31,39},{40,23},{35,19},{29,24}},ink);poly({{26,38},{30,38},{37,24},{34,22}},light);rect(29,18,19,7,ink);rect(32,18,14,4,mid);rect(40,15,9,4,dark);rect(37,30,15,4,dark);rect(40,29,10,2,white);rect(52,37,15,9,steel);rect(54,38,11,5,white)
  for j=0,4 do rect(78+j*7,26,5,19,ink);rect(79+j*7,28,3,14,({'7ebdc3','9cc690','bf9ead'})[j%3+1]);rect(79+j*7,24,3,3,white) end;rect(74,41,42,7,steel)
 elseif variant=='glassware' then
  for j=0,3 do local x=14+j*24;rect(x+7,18,6,10,steel);rect(x+8,18,4,12,white);poly({{x+7,28},{x+13,28},{x+20,43},{x,43}},blue);poly({{x+7,30},{x+13,30},{x+18,42},{x+2,42}},j%2==0 and green or cyan);line(x+4,38,x+8,29,white);rect(x+6,17,8,3,mid) end
 else screen(15,18,47,28,2);rect(16,47,46,5,dark);for y=48,50,2 do for x=19,59,4 do rect(x,y,2,1,mid) end end;panel(78,22,34,28,white);ell(84,25,22,16,steel);ell(87,27,16,12,dark);for k=0,3 do ell(90+(k%2)*7,29+math.floor(k/2)*5,4,3,amber) end end
 flush();save(name)
end
bench('mesa_microscopio','microscope');bench('mesa_cultivos','glassware');bench('mesa_secuenciador','machine')

new(144,96);layer('Cabina de bioseguridad');panel(2,3,140,84,light);rect(9,14,126,47,ink);rect(13,17,118,39,'648e98');rect(17,20,110,33,'96bdbe');rect(15,19,3,32,white);rect(14,53,116,8,mid);rect(11,13,122,3,cyan);for k=0,5 do local x=26+k*17;rect(x,36,7,15,steel);rect(x+1,37,5,11,k%2==0 and green or cyan);rect(x,34,7,3,white) end;rect(13,64,56,13,steel);screen(83,64,39,13,1);for x=18,65,5 do rect(x,67,2,6,dark) end;flush();save('cabina_bioseguridad')

new(96,112);layer('Biorreactor')
for f=1,8 do if f>1 then S:newEmptyFrame() end;I=Image(96,112,ColorMode.RGB);ell(4,95,88,14,'91aaa0');panel(9,15,78,86,steel);rect(18,27,60,53,ink);rect(21,30,54,46,'426c65');rect(24,34,48,39,'629471');ell(28,41,20,22,'90b88c');ell(49,36,20,30,'a1c395');for j=0,6 do local x=27+(j*11)%43;local y=35+(j*7-f*3)%35;box(x,y,2,3,'cee6b2') end;rect(17,26,3,52,white);rect(75,28,3,49,mid);rect(22,21,52,3,cyan);screen(30,84,36,10,f,green);rect(14,6,68,13,ink);rect(17,7,62,9,light);for x=22,72,8 do rect(x,9,3,5,steel) end;flush(f) end
local t=S:newTag(1,8);t.name='Cultivo';for _,f in ipairs(S.frames) do f.duration=.18 end;save('biorreactor',true)

new(160,80);layer('Consola de control')
for f=1,8 do if f>1 then S:newEmptyFrame() end;I=Image(160,80,ColorMode.RGB);panel(2,4,156,67,steel);screen(9,10,68,39,f);screen(82,10,68,39,7-f,green);rect(10,53,140,10,light);for x=17,140,7 do rect(x,56,3,2,dark) end;rect(20,64,120,3,dark);rect(22,65,35,1,mid);ell(126,54,8,8,amber);flush(f) end
for _,f in ipairs(S.frames)do f.duration=.22 end;local t=S:newTag(1,8);t.name='Telemetria';save('consola_control',true)

new(192,80);layer('Panel de vigilancia')
for f=1,8 do if f>1 then S:newEmptyFrame() end;I=Image(192,80,ColorMode.RGB);panel(2,2,188,70,dark);for n=0,2 do screen(10+n*59,10,54,44,f+n) end;rect(10,57,172,7,steel);for n=0,8 do rect(17+n*19,59,8,2,n==f and amber or green) end;flush(f) end;for _,f in ipairs(S.frames)do f.duration=.24 end;save('muro_monitores',true)

new(80,96);layer('Armario esteril');panel(3,2,74,85,light);for n=0,1 do box(9+n*33,13,28,62,steel);rect(11+n*33,15,24,18,'92b0b8');rect(12+n*33,15,2,17,white);rect(29+n*33,39,3,12,dark);for j=0,3 do rect(13+n*33,65+j*2,18,1,steel) end end;rect(15,5,48,3,cyan);flush();save('armario_esteril')

new(128,80);layer('Ducha descontaminacion');panel(3,4,122,66,light);rect(11,13,106,38,steel);rect(14,15,100,32,'c1d4d1');for n=0,2 do rect(23+n*34,17,21,25,'b2c9c7');line(24+n*34,18,42+n*34,18,white);rect(30+n*34,20,7,3,dark);rect(31+n*34,23,5,2,cyan) end;rect(12,54,104,8,dark);for x=16,110,5 do rect(x,56,2,4,mid) end;flush();save('duchas')

new(96,80);layer('Autoclave');panel(2,2,92,68,light);ell(9,10,53,49,ink);ell(11,11,49,45,steel);ell(16,15,39,37,mid);ell(20,19,31,29,dark);ell(23,21,25,24,'536e79');rect(29,27,13,3,mid);rect(34,23,3,14,mid);screen(67,13,20,23,1);rect(68,42,18,12,steel);ell(74,44,6,6,amber);flush();save('autoclave')

new(96,112);layer('Sintetizador viral')
for f=1,8 do if f>1 then S:newEmptyFrame() end;I=Image(96,112,ColorMode.RGB);panel(4,4,88,98,light);screen(15,15,65,26,f,amber);rect(15,48,65,37,ink);for k=0,4 do rect(20+k*12,56,7,22,steel);rect(21+k*12,60,5,15,k==f%5 and amber or green);rect(20+k*12,52,7,5,white) end;rect(11,90,74,5,dark);for k=0,7 do poly({{12+k*9,90},{16+k*9,90},{20+k*9,94},{16+k*9,94}},amber) end;flush(f) end;for _,f in ipairs(S.frames) do f.duration=.2 end;save('sintetizador',true)

new(128,64);layer('Carga biologica');panel(2,4,124,50,steel);for n=0,2 do local x=11+n*38;rect(x,13,32,29,ink);rect(x+2,15,28,25,'b9c9bb');rect(x+4,15,3,25,light);rect(x+24,15,3,25,light);ell(x+11,20,10,10,dark);ell(x+14,23,4,4,amber);rect(x+8,34,16,3,dark) end;flush();save('contenedores_bio')

new(64,80);layer('Carro de muestras');rect(8,62,10,10,ink);rect(46,62,10,10,ink);panel(5,23,54,42,light);rect(8,17,48,4,steel);rect(8,17,3,16,ink);rect(53,17,3,16,ink);for n=0,3 do rect(13+n*10,31,7,16,blue);rect(14+n*10,32,5,13,n%2==0 and cyan or green);rect(13+n*10,28,7,4,white) end;rect(12,53,40,5,steel);flush();save('carro_muestras')

new(64,64);layer('Banco metal');panel(3,16,58,32,light);rect(9,48,7,8,dark);rect(48,48,7,8,dark);rect(9,24,46,12,'8da7ad');rect(10,25,44,2,mid);flush();save('banco')

new(48,64);layer('Terminal acceso');rect(17,42,14,11,ink);ell(7,49,34,10,steel);panel(3,3,42,40,light);screen(10,10,28,22,1);rect(10,34,28,3,dark);flush();save('terminal')

new(48,64);layer('Planta contenida');ell(8,42,33,17,dark);ell(8,39,33,14,light);rect(10,44,29,7,mid);ell(13,40,23,9,'647b72');for n=0,5 do local x=24+math.cos(n*math.pi/3)*12;local y=27+math.sin(n*math.pi/3)*10;line(24,44,x,y,'487b60');ell(x-6,y-7,12,14,n%2==0 and '81aa78' or '5f8d70');line(x,y-4,x-2,y+4,'b2c595') end;flush();save('planta')

new(128,32);layer('Paso de seguridad');rect(0,3,128,24,steel);rect(1,5,126,20,mid);for x=5,120,8 do rect(x,7,3,16,'819da4') end;rect(0,3,128,2,light);rect(0,26,128,2,ink);flush();save('umbral')

dofile(base..'tools/build_scientists.lua')

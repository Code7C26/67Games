-- Adapt the actual NPC 1/2/3 sheets. Faces, silhouettes and step poses are untouched.
local b=LAB_BASE
local pc=app.pixelColor
local function hex(s)local v=tonumber(s,16);return pc.rgba((v>>16)&255,(v>>8)&255,v&255,255) end
local colors={{'b84f56','813d50','8f5260','bf6165'},{'96b96b','51846e','65907a','a2bf78'},{'a875bc','75537f','846589','b183bf'}}
local replacements={'e3e9df','829ba7','b4c8ce','f6f4e6'}
local dirs={'abajo','arriba','derecha','izquierda'}
local names={'Abajo','Arriba','Derecha','Izquierda'}
local total_checked,changed_head,changed_alpha=0,0,0
for n=1,3 do
 local s=Sprite(32,32,ColorMode.RGB);local original=s.layers[1];original.name='NPC original - conservado';local coat=s:newLayer();coat.name='Bata clinica - solapas - credencial'
 local f=0
 for d,dir in ipairs(dirs) do
  local src=Image{fromFile=b..'demo/referencias_originales/NPC '..n..' '..dir..'.png'};local count=(src.width//32)*(src.height//32);local first=f+1
  for step=0,count-1 do
   f=f+1;if f>1 then s:newEmptyFrame() end
   local img=Image(src,Rectangle((step%(src.width//32))*32,(step//(src.width//32))*32,32,32));s:newCel(original,f,img,Point(0,0));local edit=Image(32,32);local result=Image(img)
   local cloth={};for k,c in ipairs(colors[n])do cloth[hex(c)]=hex(replacements[k]) end
   local minx,maxx,miny,maxy=32,0,32,0
   for y=0,31 do for x=0,31 do local p=img:getPixel(x,y);if cloth[p] then edit:drawPixel(x,y,cloth[p]);result:drawPixel(x,y,cloth[p]);minx=math.min(minx,x);maxx=math.max(maxx,x);miny=math.min(miny,y);maxy=math.max(maxy,y) end end end
   local center=math.floor((minx+maxx)/2)
   local function put(x,y,c)
    if x<0 or x>31 or y<miny or y>maxy+2 then return end
    local p=img:getPixel(x,y)
    if pc.rgbaA(p)==0 or p==hex('292638') or p==hex('e8ba87') or p==hex('b47e5b') then return end
    edit:drawPixel(x,y,hex(c));result:drawPixel(x,y,hex(c))
   end
   -- Longer coat hem, retaining the original silhouette and separating both legs.
   for y=maxy,maxy+2 do for x=minx+3,maxx-3 do if x~=center then put(x,y,'c6d6d6') end end end
   if d==1 then
    for y=miny+1,miny+3 do put(center,y,'568a99');put(center+1,y,'568a99') end
    put(center-1,miny+1,'ffffff');put(center+2,miny+1,'ffffff');put(center,miny+4,'6e8d9b')
    for y=miny+5,maxy do put(center,y,'98b2bb') end
    put(center+4,miny+3,'4d979e');put(center+4,miny+4,'76ccca');put(center+3,miny+3,'f6f4e6')
    put(center-4,maxy-1,'8eaab7');put(center-3,maxy-1,'8eaab7')
   elseif d==2 then
    for x=minx+3,maxx-3 do put(x,maxy-1,'a7bec5') end
    put(center,miny+2,'b1c8cc')
   else
    local side=d==3 and -1 or 1
    put(center+side*2,miny+4,'80c8c8');put(center+side*2,miny+5,'508b98');put(center,maxy-1,'8da8b6')
   end
   s:newCel(coat,f,edit,Point(0,0));s.frames[f].duration=.20
   for y=0,31 do for x=0,31 do local p,q=img:getPixel(x,y),result:getPixel(x,y);if pc.rgbaA(p)~=pc.rgbaA(q) then changed_alpha=changed_alpha+1 end;if y<miny and p~=q then changed_head=changed_head+1 end;total_checked=total_checked+1 end end
  end
  local tag=s:newTag(first,f);tag.name=names[d]
 end
 -- Aseprite can extend tags when later frames are inserted. Fix their final bounds.
 for d,t in ipairs(s.tags) do t.fromFrame=s.frames[({1,3,5,9})[d]];t.toFrame=s.frames[({2,4,8,12})[d]] end
 s:saveAs(b..'lab/assets/cientifico_'..n..'.aseprite');app.activeSprite=s
 app.command.ExportSpriteSheet{ui=false,type=SpriteSheetType.HORIZONTAL,textureFilename=b..'lab/assets/cientifico_'..n..'.png',dataFilename=b..'lab/assets/cientifico_'..n..'.json',dataFormat=SpriteSheetDataFormat.JSON_ARRAY,listTags=true,listLayers=true}
 print('NPC '..n..' adapted: '..f..' original frames, separate coat layer');s:close()
end
assert(changed_alpha==0 and changed_head==0)
print('PRESERVATION_OK pixels='..total_checked..' altered_head_pixels='..changed_head..' altered_alpha_pixels='..changed_alpha)

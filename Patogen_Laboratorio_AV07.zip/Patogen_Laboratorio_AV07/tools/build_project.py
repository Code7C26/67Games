"""Generate native, editable Godot scenes. Raster art is authored by build_art.lua in Aseprite."""
from pathlib import Path
import json, shutil, re

ROOT=Path(__file__).resolve().parents[1]
shutil.copy2(ROOT/'assets/Pixel-Regular.ttf', ROOT/'lab/assets/Pixel-Regular.ttf')
assets={
 'capsula_pato':(96,144,8,.16), 'biorreactor':(96,112,8,.18),
 'consola_control':(160,80,8,.22),'muro_monitores':(192,80,8,.24),'sintetizador':(96,112,8,.20),
 'mesa_microscopio':(128,72,1,0),'mesa_cultivos':(128,72,1,0),'mesa_secuenciador':(128,72,1,0),
 'cabina_bioseguridad':(144,96,1,0),'armario_esteril':(80,96,1,0),'duchas':(128,80,1,0),
 'autoclave':(96,80,1,0),'contenedores_bio':(128,64,1,0),'carro_muestras':(64,80,1,0),
 'banco':(64,64,1,0),'terminal':(48,64,1,0),'planta':(48,64,1,0),'umbral':(128,32,1,0)}
# Top-left placement coordinates. Collision rectangles follow the visible apparatus.
props=[]
def p(name,x,y,label=''): props.append({'asset':name,'x':x,'y':y,'name':label or name+'_'+str(len(props))})
for i in range(6):p('capsula_pato',1120+i*120,132,'Criopato_%02d'%(i+1))
p('cabina_bioseguridad',64,124);p('mesa_microscopio',256,144);p('mesa_secuenciador',432,144)
p('mesa_cultivos',80,232);p('mesa_microscopio',368,232)
for x in [656,800,944]:p('biorreactor',x,140)
p('mesa_cultivos',784,292)
p('terminal',1816,320)
p('autoclave',64,752);p('duchas',224,752);p('carro_muestras',416,768)
p('muro_monitores',592,752);p('consola_control',864,760);p('mesa_secuenciador',752,624)
p('sintetizador',1136,736);p('sintetizador',1360,736)
p('contenedores_bio',1552,768);p('contenedores_bio',1712,768);p('armario_esteril',1800,624)
for x in [304,816,1392]:p('banco',x,432)
for x,y in [(48,440),(1808,448),(1040,632)]:p('planta',x,y)

walls=[]
def wh(x,y,w):walls.append([x,y,w,32,False])
def wv(x,y,h):walls.append([x,y,32,h,True])
wh(16,80,1888);wh(16,848,1888);wv(16,112,736);wv(1872,112,736)
# Cross-room connections retain a continuous alternative ring.
for x in [592,1072]:wv(x,112,160)
for x in [496,1072,1488]:wv(x,624,32);wv(x,784,64)
doors_top=[(144,272),(432,560),(656,784),(912,1040),(1168,1328),(1648,1808)]
doors_bottom=[(80,208),(336,464),(592,720),(880,1008),(1120,1248),(1328,1456),(1552,1680),(1712,1840)]
def wall_with_doors(y,doors):
 last=48
 for a,b in doors:
  if a>last:wh(last,y,a-last)
  last=b
 if last<1872:wh(last,y,1872-last)
wall_with_doors(400,doors_top);wall_with_doors(592,doors_bottom)
rooms=[
 {'name':'01  /  GENOMICA','rect':[48,112,544,288],'color':'9faec5','tile':1,'label':[64,114]},
 {'name':'02  /  CULTIVO','rect':[624,112,448,288],'color':'99b896','tile':2,'label':[640,114]},
 {'name':'03  /  CRIOGENIA','rect':[1104,112,768,288],'color':'8ec2cb','tile':3,'label':[1120,114]},
 {'name':'04  /  DESCONTAMINACION','rect':[48,624,448,224],'color':'c6a59b','tile':4,'label':[64,824]},
 {'name':'05  /  CONTROL','rect':[528,624,544,224],'color':'91b4ca','tile':5,'label':[544,824]},
 {'name':'06  /  SINTESIS','rect':[1104,624,384,224],'color':'c8b576','tile':6,'label':[1120,824]},
 {'name':'07  /  LOGISTICA','rect':[1520,624,352,224],'color':'a9bcb6','tile':7,'label':[1536,824]}]
markers=[
 ['InicioPato_A',272,528,'patogen_spawn'],['InicioPato_B',1648,528,'patogen_spawn'],
 ['Genomica_01',272,352,'patogen_destination'],['Genomica_02',496,352,'patogen_destination'],
 ['Cultivo_01',688,352,'patogen_destination'],['Cultivo_02',1008,352,'patogen_destination'],
 ['Criogenia_01',1232,352,'patogen_destination'],['Criogenia_02',1728,352,'patogen_destination'],
 ['Descontaminacion',272,704,'patogen_destination'],['Control',800,704,'patogen_destination'],
 ['Sintesis',1296,688,'patogen_destination'],['Logistica',1648,704,'patogen_destination'],
 ['Cruce_Oeste',176,528,'patogen_destination'],['Cruce_Central',944,528,'patogen_destination'],
 ['Cruce_Este',1744,528,'patogen_destination'],
 ['Zona_Fria_Candidata',1440,352,'patogen_strategy'],['Zona_Caliente_Candidata',1296,528,'patogen_strategy'],
 ['Robot_Oeste',400,528,'patogen_strategy'],['Robot_Este',1552,528,'patogen_strategy']]
data={'assets':assets,'props':props,'walls':walls,'rooms':rooms,'markers':markers,'doors_top':doors_top,'doors_bottom':doors_bottom}
(ROOT/'tools/layout.json').write_text(json.dumps(data,indent=2),encoding='utf8')

gd='''extends SceneTree
var data: Dictionary
var root: Node2D
var floor_layer: TileMapLayer
var objects: Node2D
var obstacles: Array = []
var font = load("res://lab/assets/Pixel-Regular.ttf")
func _initialize() -> void:
 call_deferred("build")
func own_tree(n: Node, owner_root: Node) -> void:
 for c in n.get_children():
  c.owner = owner_root
  if c.scene_file_path.is_empty():own_tree(c, owner_root)
func pack(n: Node, path: String) -> void:
 own_tree(n,n)
 var ps := PackedScene.new()
 assert(ps.pack(n)==OK)
 assert(ResourceSaver.save(ps,path)==OK)
func group(name_: String, parent: Node) -> Node2D:
 var n:=Node2D.new();n.name=name_;parent.add_child(n);return n
func rect_node(parent: Node, r: Rect2, color: Color, name_: String) -> Polygon2D:
 var n:=Polygon2D.new();n.name=name_;n.polygon=PackedVector2Array([r.position,r.position+Vector2(r.size.x,0),r.end,r.position+Vector2(0,r.size.y)]);n.color=color;parent.add_child(n);return n
func label(parent:Node, text_:String, pos:Vector2, color:Color, size_:int=16) -> Label:
 var n:=Label.new();n.text=text_;n.position=pos;n.mouse_filter=Control.MOUSE_FILTER_IGNORE;n.add_theme_font_override("font",font);n.add_theme_font_size_override("font_size",size_);n.add_theme_color_override("font_color",color);parent.add_child(n);return n
func atlas(tex: Texture2D, r: Rect2) -> AtlasTexture:
 var a:=AtlasTexture.new();a.atlas=tex;a.region=r;return a
func make_frames(asset:String) -> SpriteFrames:
 var info:Array=data.assets[asset];var frames:=SpriteFrames.new();frames.set_animation_speed("default",1.0/float(info[3]));var tex=load("res://lab/assets/"+asset+".png")
 for i in range(int(info[2])):frames.add_frame("default",atlas(tex,Rect2(i*info[0],0,info[0],info[1])))
 return frames
func collision(parent: Node, r: Rect2) -> void:
 var b:=StaticBody2D.new();b.name="Colision";b.collision_layer=1;b.collision_mask=0;parent.add_child(b)
 var c:=CollisionShape2D.new();c.name="Shape";var sh:=RectangleShape2D.new();sh.size=r.size;c.shape=sh;c.position=r.get_center();b.add_child(c)
func footprint(asset:String,w:float,h:float) -> Rect2:
 if asset=="banco":return Rect2(4,19,w-8,30)
 if asset=="planta":return Rect2(8,20,w-16,h-29)
 if asset=="umbral":return Rect2()
 if asset=="capsula_pato":return Rect2(9,15,w-18,h-23)
 return Rect2(4,9,w-8,h-18)
func build_props() -> void:
 DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://lab/scenes/objetos"))
 for asset in data.assets:
  var info:Array=data.assets[asset];var w:float=info[0];var h:float=info[1];var n:=Node2D.new();n.name=asset.to_pascal_case();n.set_script(load("res://lab/scripts/prop_animation.gd"))
  if info[2]>1:
   var s:=AnimatedSprite2D.new();s.name="TexturaAnimada";s.sprite_frames=make_frames(asset);s.centered=false;s.position=Vector2(-w/2,-h);s.autoplay="default";n.add_child(s)
  else:
   var s:=Sprite2D.new();s.name="Textura";s.texture=load("res://lab/assets/"+asset+".png");s.centered=false;s.position=Vector2(-w/2,-h);n.add_child(s)
  var foot:=footprint(asset,w,h);n.set_meta("footprint",foot);n.set_meta("size",Vector2(w,h))
  if foot.has_area():collision(n,Rect2(foot.position-Vector2(w/2,h),foot.size))
  n.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
  pack(n,"res://lab/scenes/objetos/"+asset+".tscn");n.free()
func build_tiles() -> void:
 var tiles:=TileSet.new();tiles.tile_size=Vector2i(32,32)
 var source:=TileSetAtlasSource.new();source.texture=load("res://lab/assets/laboratorio_tiles.png");source.texture_region_size=Vector2i(32,32)
 for y in range(4):
  for x in range(8):source.create_tile(Vector2i(x,y))
 tiles.add_source(source,0);ResourceSaver.save(tiles,"res://lab/assets/laboratorio_tiles.tres")
 floor_layer=TileMapLayer.new();floor_layer.name="01_Pisos";floor_layer.tile_set=tiles;floor_layer.position=Vector2(16,80);root.add_child(floor_layer)
 for y in range(25):
  for x in range(59):
   var p:=Vector2(16+x*32+16,80+y*32+16);var mat:=0
   for room in data.rooms:
    var r:Array=room.rect
    if Rect2(r[0],r[1],r[2],r[3]).has_point(p):mat=room.tile
   var variant:=1 if (x*7+y*3)%17==0 else (2 if (x*3+y*11)%31==0 else 0)
   floor_layer.set_cell(Vector2i(x,y),0,Vector2i(mat,variant))
func build_walls() -> void:
 var parent:=group("03_Paredes_y_colisiones",root)
 var tex=load("res://lab/assets/laboratorio_tiles.png")
 for i in range(data.walls.size()):
  var a:Array=data.walls[i];var n:=group("Pared_%03d"%i,parent);n.position=Vector2(a[0],a[1]);var vertical:bool=a[4];var count:=int((a[3] if vertical else a[2])/32)
  for j in range(count):
   var sp:=Sprite2D.new();sp.texture=atlas(tex,Rect2((1 if j%5==2 else 0)*32,96,32,32));sp.position=Vector2(16,16)+Vector2(0,j*32) if vertical else Vector2(16+j*32,16)
   if vertical:sp.rotation=PI/2
   n.add_child(sp)
  collision(n,Rect2(0,0,a[2],a[3]));obstacles.append([a[0],a[1],a[2],a[3]])
func build_details() -> void:
 var d:=group("02_Senaletica_y_luces",root)
 # Four clean tracks and discreet wayfinding on the principal corridor.
 for y in [448,572]:
  rect_node(d,Rect2(48,y,1824,3),Color("9cb5b8"),"Guia")
 for x in range(96,1840,192):
  for y in [479,553]:rect_node(d,Rect2(x,y,32,2),Color("aabfc0"),"Baliza")
 label(d,"AV-07",Vector2(864,475),Color("486a76"),30)
 label(d,"BIOARMAS / NIVEL 04",Vector2(824,515),Color("6b8991"),15)
 label(d,"ACCESO CONTROLADO",Vector2(64,506),Color("718e96"),13)
 label(d,"TRANSFERENCIA ESTERIL",Vector2(1616,506),Color("718e96"),13)
 for side in [0,1]:
  var doors:Array=data.doors_top if side==0 else data.doors_bottom
  var y:float=404 if side==0 else 596
  for pair in doors:
   var x:float=pair[0];var w:float=pair[1]-pair[0]
   rect_node(d,Rect2(x,y,w,24),Color("97b5b9"),"Paso")
   rect_node(d,Rect2(x+2,y+2,w-4,2),Color("e7eee0"),"Umbral")
   for xx in range(int(x)+8,int(x+w)-4,12):rect_node(d,Rect2(xx,y+7,2,10),Color("6f929c"),"Rejilla")
   rect_node(d,Rect2(x,y-2,5,28),Color("e4d9ac"),"Jamba")
   rect_node(d,Rect2(x+w-5,y-2,5,28),Color("e4d9ac"),"Jamba")
 for i in range(6):
  label(d,"AV / %02d"%(i+1),Vector2(1134+i*120,292),Color("527d87"),14)
 label(d,"VECTOR AVIAR  /  CRIOSTASIS",Vector2(1336,368),Color("668d95"),15)
 label(d,"MUESTRAS ESTERILES",Vector2(64,372),Color("7b879c"),13)
 label(d,"CULTIVO CONTROLADO",Vector2(752,372),Color("708d75"),13)
func build_map() -> void:
 root=Node2D.new();root.name="LaboratorioAV07";root.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
 root.set_meta("viewport_size",Vector2i(1920,1080));root.set_meta("play_rect",Rect2(16,80,1888,800));root.set_meta("hud_top",Rect2(0,0,1920,68));root.set_meta("hud_bottom",Rect2(0,890,1920,190))
 build_tiles();build_details();build_walls();objects=group("04_Objetos",root);objects.y_sort_enabled=true
 for i in range(data.props.size()):
  var prop:Dictionary=data.props[i];var info:Array=data.assets[prop.asset];var ps:PackedScene=load("res://lab/scenes/objetos/"+prop.asset+".tscn");var n:Node2D=ps.instantiate();n.name=prop.name;n.position=Vector2(prop.x+info[0]/2.0,prop.y+info[1]);objects.add_child(n)
  var f:Rect2=n.get_meta("footprint");if f.has_area():obstacles.append([prop.x+f.position.x,prop.y+f.position.y,f.size.x,f.size.y])
  n.animation_offset=i%8
 var signs:=group("05_Rotulos",root)
 for room in data.rooms:
  var xy:Array=room.label;var w:int=int(font.get_string_size(room.name,HORIZONTAL_ALIGNMENT_LEFT,-1,16).x)+26
  rect_node(signs,Rect2(xy[0]-3,xy[1]-3,w,23),Color("344d5b"),"Placa")
  rect_node(signs,Rect2(xy[0]-3,xy[1]-3,4,23),Color(room.color),"CodigoColor")
  label(signs,room.name,Vector2(xy[0]+8,xy[1]),Color("e4eadc"),16)
 var points:=group("06_Marcadores",root)
 for m in data.markers:
  var n:=Marker2D.new();n.name=m[0];n.position=Vector2(m[1],m[2]);n.add_to_group(m[3],true);points.add_child(n)
 root.set_meta("obstacles",obstacles)
 pack(root,"res://lab/scenes/Laboratorio.tscn");root.free()
func build_scientists() -> void:
 for i in range(1,4):
  var frames:=SpriteFrames.new();frames.remove_animation("default");var tex=load("res://lab/assets/cientifico_%d.png"%i)
  var frame_start:=0
  for d in range(4):
   var nm:String=["Abajo","Arriba","Derecha","Izquierda"][d];frames.add_animation(nm);frames.set_animation_speed(nm,5.0)
   var count:int=[2,2,4,4][d]
   for f in range(count):frames.add_frame(nm,atlas(tex,Rect2((frame_start+f)*32,0,32,32)))
   frame_start+=count
  ResourceSaver.save(frames,"res://lab/assets/cientifico_%d.tres"%i)
  var n:=Node2D.new();n.name="Cientifico%d"%i;var sp:=AnimatedSprite2D.new();sp.name="AnimatedSprite2D";sp.sprite_frames=frames;sp.animation="Abajo";sp.autoplay="Abajo";sp.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;n.add_child(sp);pack(n,"res://lab/scenes/Cientifico%d_visual.tscn"%i);n.free()
func build_catalogue() -> void:
 var n:=Node2D.new();n.name="CatalogoLaboratorio";n.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;n.set_script(load("res://demo/catalog.gd"))
 var idx:=0
 for asset in data.assets:
  var x:=80+(idx%6)*300;var y:=120+int(idx/6)*220
  var bg:=rect_node(n,Rect2(x-24,y-20,272,202),Color("253b49"),"Ficha")
  var obj:Node2D=load("res://lab/scenes/objetos/"+asset+".tscn").instantiate();obj.position=Vector2(x+112,y+136);n.add_child(obj);label(n,asset,Vector2(x-10,y+150),Color("dce6df"),14);idx+=1
 label(n,"AV-07 / CATALOGO DE OBJETOS",Vector2(56,38),Color("b6d3cc"),28)
 for i in range(1,4):
  var sc:Node2D=load("res://lab/scenes/Cientifico%d_visual.tscn"%i).instantiate();sc.position=Vector2(120+i*200,940);sc.scale=Vector2(3,3);n.add_child(sc);label(n,"CIENTIFICO %d"%i,Vector2(60+i*200,1000),Color("dce6df"),16)
 label(n,"ESC / F2: VOLVER AL LABORATORIO",Vector2(1100,1012),Color("9bb5bd"),18)
 pack(n,"res://demo/Catalogo.tscn");n.free()
func build() -> void:
 data=JSON.parse_string(FileAccess.get_file_as_string("res://tools/layout.json"))
 build_props();build_scientists();build_map();build_catalogue()
 print("BUILD_OK: editable map, 18 modular props, 3 scientist skins, catalogue")
 quit()
'''
gd=re.sub(r'\broot\b','map_root',gd)
(ROOT/'tools/build_scene.gd').write_text(gd,encoding='utf8')
print('Build sources written:',ROOT)

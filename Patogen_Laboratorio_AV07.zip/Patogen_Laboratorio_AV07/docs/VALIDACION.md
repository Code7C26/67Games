# Verificación · 23 de octubre de 2026

Godot 4.7.1 y Aseprite 1.3.17, utilizados por sus MCP. Capturas tomadas desde Godot y revisadas a 1920 × 1080.

## Resultados

- **169 pares de destinos conectados**, incluyendo recorridos de vuelta.
- **182 comprobaciones de acceso alternativo**: se cerró de a una cada entrada principal y se verificó que todos los sectores siguieran conectados.
- **169 pares conectados con un margen de 36 px**, equivalente a espacio geométrico para un cuerpo de 72 px. Esta prueba de geometría no representa una simulación de robots reales.
- **HUD sin intersección** con el área completa del mapa.
- **36 actores durante 120 segundos simulados**, cápsulas de radio 11.5 y altura 32 como el Bot local consultado. Colisión sólida con el entorno; separación suave entre actores, que pueden solaparse si coinciden. No se validan colisiones físicas entre los NPC reales.
- Recorrido mínimo por actor: **6158.6 px**. Rutas terminadas: **334**. Actores inactivos: **0**.
- Muestras con penetraciones de paredes superiores a la tolerancia de 0.25 px: **0**. Muestreo cada dos segundos.
- La demo usó **18 cambios de destino por bloqueos momentáneos**; el mayor bloqueo registrado fue de **1.82 s**. No se afirma ausencia de todo contacto o congestión. Los actores de prueba se separan al cruzarse y replantean sus recorridos.
- Científicos: **36 fotogramas originales adaptados**, 36.864 píxeles comparados; **cero cambios en cabezas y transparencia/silueta**. Batas en una capa separada. Mismas cantidades y orden de cuadros por dirección que los NPC originales.
- Atlas, 18 objetos modulares y científicos con PNG y fuente `.aseprite`. Cinco tipos de equipos con ciclos de ocho cuadros; los científicos conservan sus cuatro caminatas.
- Tres capturas verificadas de 1920 × 1080 y un GIF de 24 cuadros capturado en Godot.
- La ejecución final de la prueba terminó sin fallos, errores de script ni avisos de recursos filtrados. Resultados completos en `tests/validation.json`.

## Alcance real

La circulación se verificó con actores de demostración y la geometría del laboratorio. La entrega no incorpora los sistemas de infección, posesión, temperatura ni teletransporte del juego. La IA reactiva del `Bot.gd` real no es la navegación de la demo: antes de publicar el nivel hay que probar partidas completas con sus NPC, habilidades, poblaciones y robots reales. Las posiciones iniciales son propuestas comparables, no balance competitivo medido.

## Repetir

`Godot --headless --path <carpeta> --fixed-fps 60 --script tests/validate.gd`

`Godot --path <carpeta> tests/Capture.tscn`

Las pruebas no requieren modificar el shopping ni el proyecto de mecánicas. Los SHA256 de las 12 hojas originales están en `docs/referencias_sha256.json`.

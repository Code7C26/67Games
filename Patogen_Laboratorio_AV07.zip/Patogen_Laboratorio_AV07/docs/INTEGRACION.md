# Integrar el laboratorio en Patogen

## Mapa

1. Copiar la carpeta **`lab` completa** a la raíz del proyecto de mecánicas. Mantener las rutas `res://lab/...`.
2. Instanciar `res://lab/scenes/Laboratorio.tscn` dentro de la escena que ya tiene el controlador de partida, en **(0, 0)**, escala **(1, 1)**. Sustituir la instancia del mapa anterior en esa partida; no superponer ambos mapas.
3. Conservar los scripts de partida, jugadores y bots existentes. El laboratorio sólo contiene entorno, colisiones, marcadores y animación ambiental.
4. La física del entorno está en **capa 1**, máscara 0. Los NPC deben consultar capa 1. No duplicar las colisiones en una segunda instancia.
5. Usar los marcadores de `06_Marcadores` por su `global_position`. Las apariciones sugeridas son **InicioPato_A (272, 528)** y **InicioPato_B (1648, 528)**. Ambos acceden al corredor y a sectores próximos; el balance requiere partidas reales.

## Cámara y HUD

El lienzo completo mide **1920 × 1080**. El área del mapa es **Rect2(16, 80, 1888, 800)**. El HUD ocupa la banda superior hasta y=68 y la inferior desde y=890. Se conserva un margen entre mapa y paneles. La demo no necesita cámara: sus coordenadas de mundo coinciden con las del lienzo.

Si se usa el `match_hud.gd` consultado de `Desktop/proyecto`, su `MAP_RECT` corresponde al shopping. Para seleccionar este mapa, hacer que `world_rect` tome la metadata `play_rect` de la instancia del laboratorio. En `_layout`, limitar el zoom calculado a **1.0** para conservar la escala nativa a 1920 × 1080. Mantener el cálculo de centrado en la zona libre que ya utiliza ese HUD. La cámara debe ser fija; no seguir al pato.

La demo contiene una copia de referencia de ese HUD, sin llamar a `setup` ni conectar mecánicas: sus cifras y botones no constituyen una partida. No copiar `demo/hud_referencia.gd` encima del HUD de producción.

## Científicos

En el `Bot.tscn` real, agregar o asignar a `skins`:

- `res://lab/assets/cientifico_1.tres`
- `res://lab/assets/cientifico_2.tres`
- `res://lab/assets/cientifico_3.tres`

Conservan las animaciones **Abajo, Arriba, Derecha, Izquierda**, 2/2/4/4 fotogramas a 5 FPS, y las celdas de **32 × 32** de los NPC existentes. Las hojas direccionales también se incluyen: abajo/arriba de 32 × 64, derecha/izquierda de 64 × 64. No reescalar el cuerpo ni su colisión al cambiar el aspecto. La cápsula del Bot local consultado tiene radio 11.5 y altura 32, sin escala adicional.

Las fuentes Aseprite tienen `NPC original - conservado` y `Bata clinica - solapas - credencial`. Ocultar la segunda capa permite comparar con el original. El código de infección y sus skins infectadas siguen perteneciendo al proyecto de mecánicas: esta entrega sólo adapta la apariencia sana de los científicos.

## Navegación y contenido editable

- El corredor principal tiene 160 px entre paredes; puertas principales de 128 o 160 px y conexiones laterales de 128 px. Hay rutas alternativas por las salas conectadas.
- `patogen_destination`, `patogen_spawn` y `patogen_strategy` son grupos de marcadores orientativos. No activan habilidades ni obligan a la IA real a usarlos.
- La demo genera una cuadrícula de navegación a partir de las colisiones de la escena y usa actores de prueba. `demo/routes.gd` y `demo/scientist_walk.gd` no sustituyen el `Bot.gd` del juego.
- Los científicos de la demo colisionan con el entorno y usan separación suave entre sí; pueden solaparse si coinciden. La física entre personajes reales, su IA reactiva y las habilidades deben probarse al integrar la partida.
- Arrastrar escenas de `lab/scenes/objetos` para agregar muebles. El origen de cada objeto es su centro inferior, útil para ordenación por Y. Sus colisiones viajan con el objeto.
- Para ordenar personajes detrás/delante de los aparatos, usar el mismo contenedor con `y_sort_enabled` que `04_Objetos`, o reproducir ese orden en la escena de juego.

## Regenerar

`tools/build_art.lua` se ejecuta en Aseprite con `LAB_BASE` apuntando a la carpeta de este proyecto. `tools/build_scientists.lua` necesita las referencias originales de `demo/referencias_originales`. `tools/build_project.py` prepara el generador de escenas; Godot ejecuta `--headless --script tools/build_scene.gd`. Estos generadores sobrescriben la entrega generada: conservar antes los cambios hechos manualmente en escenas o arte.

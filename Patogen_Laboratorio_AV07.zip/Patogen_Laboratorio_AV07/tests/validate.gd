extends SceneTree
const Routes = preload("res://demo/routes.gd")
var failures: Array[String] = []
var report: Dictionary = {}

func _initialize() -> void:
	call_deferred("run_checks")
func check(ok: bool, message: String) -> void:
	if not ok: failures.append(message)

func run_checks() -> void:
	var demo = load("res://demo/VistaLaboratorio.tscn").instantiate()
	root.add_child(demo)
	await physics_frame
	var map: Node2D = demo.get_node("Laboratorio")
	var route = demo.routes
	var connected_pairs := 0
	for a in route.goals:
		for b in route.goals:
			check(not route.path(a,b).is_empty(),"Unreachable destination %s -> %s"%[a,b])
			connected_pairs += 1
	report["connected_destination_pairs"] = connected_pairs
	# Check that closing any one main entrance still leaves a route to every sector.
	var layout: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://tools/layout.json"))
	var alternate_checks := 0
	for row in [0,1]:
		var doors: Array = layout.doors_top if row==0 else layout.doors_bottom
		for door in doors:
			var blocked := Rect2(door[0],400 if row==0 else 592,door[1]-door[0],32).grow(19)
			var changed: Array[Vector2i] = []
			for id in route.free_cells:
				if blocked.has_point(route.grid.get_point_position(id)):
					route.grid.set_point_solid(id,true)
					changed.append(id)
			for destination in route.goals:
				check(not route.path(Vector2(944,528),destination).is_empty(),"No alternate access with closed door %s"%[door])
				alternate_checks+=1
			for id in changed:route.grid.set_point_solid(id,false)
	report["alternate_entrance_checks"] = alternate_checks
	var large = Routes.new()
	large.setup(map,36.0)
	var large_pairs := 0
	for a in large.goals:
		for b in large.goals:
			check(not large.path(a,b).is_empty(),"No 72px clearance route %s -> %s"%[a,b])
			large_pairs+=1
	report["connected_pairs_at_72px_clearance"] = large_pairs
	var map_rect: Rect2 = map.get_meta("play_rect")
	for panel in demo.hud.panels + demo.hud.top_boxes + [demo.hud.clock_box]:
		check(not map_rect.intersects(panel.get_global_rect()),"HUD overlaps playable rectangle")
	report["hud_clear_of_map"] = true
	var invalid_positions := 0
	var penetration_details: Array = []
	var shape := CapsuleShape2D.new()
	# Ignore the physics solver's subpixel contact tolerance; test actual penetration.
	shape.radius = 11.25
	shape.height = 31.5
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.collision_mask = 1
	for tick in range(7200):
		await physics_frame
		if tick%120 == 0:
			for actor in get_nodes_in_group("demo_scientists"):
				query.transform = Transform2D(0,actor.global_position)
				var collisions = actor.get_world_2d().direct_space_state.intersect_shape(query)
				if not collisions.is_empty():
					invalid_positions += 1
					penetration_details.append({"actor":actor.name,"pos":str(actor.global_position),"tick":tick,"obstacle":str(collisions[0].collider.get_path())})
	var min_travel := INF
	var total_trips := 0
	var recoveries := 0
	var max_stuck := 0.0
	var inactive: Array[String] = []
	for actor in get_nodes_in_group("demo_scientists"):
		min_travel = minf(min_travel,actor.travel)
		total_trips += actor.trips
		recoveries += actor.recoveries
		max_stuck = maxf(max_stuck,actor.max_stuck)
		if actor.travel<1500 or actor.trips<1:inactive.append(actor.name)
	check(inactive.is_empty(),"Inactive actors: %s"%[inactive])
	check(invalid_positions==0,"Physics penetrations: %d"%invalid_positions)
	report["simulation"] = {"seconds":120,"actors":36,"capsule_radius":11.5,"capsule_height":32,"minimum_distance_px":snappedf(min_travel,.1),"completed_routes":total_trips-recoveries,"route_recoveries":recoveries,"max_blocked_seconds":snappedf(max_stuck,.01),"wall_penetration_samples":invalid_positions,"inactive_actors":inactive}
	report["failures"] = failures
	report["penetration_details"] = penetration_details
	var file:=FileAccess.open("res://tests/validation.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"\t"))
	print("LAB_VALIDATION ",JSON.stringify(report))
	demo.queue_free()
	await process_frame
	call_deferred("quit",0 if failures.is_empty() else 1)

extends Node
func _ready() -> void:
	var view := SubViewport.new()
	view.size = Vector2i(1920,1080)
	view.world_2d = World2D.new()
	view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(view)
	var scene = load("res://demo/VistaLaboratorio.tscn").instantiate()
	view.add_child(scene)
	for i in range(40):await get_tree().process_frame
	await RenderingServer.frame_post_draw
	assert(view.get_texture().get_image().save_png("res://captures/01_laboratorio_hud_1920x1080.png")==OK)
	scene.hud.hide()
	for n in get_tree().get_nodes_in_group("demo_scientists"):n.hide()
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	assert(view.get_texture().get_image().save_png("res://captures/02_laboratorio_limpio_1920x1080.png")==OK)
	scene.queue_free()
	await get_tree().process_frame
	var cat=load("res://demo/Catalogo.tscn").instantiate()
	view.add_child(cat)
	for i in range(4):await get_tree().process_frame
	await RenderingServer.frame_post_draw
	assert(view.get_texture().get_image().save_png("res://captures/03_catalogo_1920x1080.png")==OK)
	print("CAPTURE_OK 3 x 1920x1080")
	get_tree().quit()

extends Node
func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://captures/frames"))
	var view:=SubViewport.new()
	view.size=Vector2i(1920,1080)
	view.world_2d=World2D.new()
	view.render_target_update_mode=SubViewport.UPDATE_ALWAYS
	add_child(view)
	var scene=load("res://demo/VistaLaboratorio.tscn").instantiate()
	view.add_child(scene)
	for i in range(24):
		await get_tree().create_timer(.125).timeout
		await RenderingServer.frame_post_draw
		assert(view.get_texture().get_image().save_png("res://captures/frames/frame_%02d.png"%i)==OK)
	print("RECORD_OK 24 frames @ 8 fps, 1920x1080")
	get_tree().quit()

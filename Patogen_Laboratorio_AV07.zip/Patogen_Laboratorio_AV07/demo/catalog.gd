extends Node2D
func _unhandled_key_input(event: InputEvent) -> void:
	if event.is_pressed() and not event.is_echo() and event.keycode in [KEY_ESCAPE,KEY_F2]:
		get_tree().change_scene_to_file("res://demo/VistaLaboratorio.tscn")

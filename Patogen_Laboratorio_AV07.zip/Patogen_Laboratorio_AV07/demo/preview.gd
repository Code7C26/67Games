extends Node2D
const Routes = preload("res://demo/routes.gd")
const Walker = preload("res://demo/scientist_walk.gd")
var routes: RefCounted
var hud: CanvasLayer
var crowd: Node2D
var elapsed := 0.0
var show_people := true
var paused := false

func _ready() -> void:
	routes = Routes.new()
	routes.setup($Laboratorio)
	crowd = $Laboratorio.get_node("04_Objetos")
	var starts: Array[Vector2] = []
	for i in range(36):
		var cell: Vector2i = routes.free_cells[(i*167+53)%routes.free_cells.size()]
		var pos: Vector2 = routes.grid.get_point_position(cell)
		var attempts := 0
		while not _spaced(pos,starts) and attempts<routes.free_cells.size():
			cell = routes.free_cells[(i*167+53+attempts*13)%routes.free_cells.size()]
			pos = routes.grid.get_point_position(cell)
			attempts += 1
		starts.append(pos)
		var actor = Walker.new()
		actor.name = "Cientifico_%02d"%(i+1)
		actor.routes = routes
		actor.serial = i
		actor.position = pos
		crowd.add_child(actor)
	_build_hud()
	print("LAB_DEMO_READY: 1920x1080, 36 scientists, 7 rooms, ", routes.free_cells.size(), " accessible grid cells")

func _spaced(p: Vector2, starts: Array[Vector2]) -> bool:
	for other in starts:
		if p.distance_to(other)<48.0:return false
	return true

func _build_hud() -> void:
	hud = CanvasLayer.new()
	hud.set_script(load("res://demo/hud_referencia.gd"))
	add_child(hud)
	hud.phase_label.text = "LABORATORIO AV-07"
	hud.clock_label.text = "02:00"
	hud.time_bar.value = 100
	hud.footer.text = "VISTA DE MAPA  ·  H: HUD  ·  N: CIENTIFICOS  ·  ESPACIO: PAUSA  ·  F2: CATALOGO  ·  F11: PANTALLA COMPLETA"
	hud.footer.size.x = 1760
	for team in range(2):
		hud.headings[team].text = "P%d / MUTACIONES"%(team+1)
		hud.adn_labels[team].text = "120 ADN"
		hud.infected_labels[team].text = "0 infectados"
		hud.descriptions[team].text = "Vista de mapa. Valores de muestra."
		var buttons = hud.panels[team].get_node("VBoxContainer").get_children()
		for j in range(3):
			buttons[j].text = ["Fiebre  ·  15 ADN","Contagio  ·  20 ADN","Infeccion  ·  25 ADN"][j]
			buttons[j].icon = hud.mutation_icons[["fiebre","contagio_cadena","infeccion_inmortal"][j]]
		for j in range(4):
			hud.ability_buttons[team][j].text = ["Robot","Zona fria","Zona caliente","Poseer"][j]

func _unhandled_key_input(event: InputEvent) -> void:
	if not event.is_pressed() or event.is_echo():return
	if event.keycode == KEY_H: hud.visible = not hud.visible
	if event.keycode == KEY_N:
		show_people = not show_people
		for n in get_tree().get_nodes_in_group("demo_scientists"):n.visible=show_people
	if event.keycode == KEY_SPACE:
		paused = not paused
		for n in get_tree().get_nodes_in_group("demo_scientists"):n.paused=paused
	if event.keycode == KEY_F2:get_tree().change_scene_to_file("res://demo/Catalogo.tscn")
	if event.keycode == KEY_F11:
		var mode := DisplayServer.WINDOW_MODE_WINDOWED if DisplayServer.window_get_mode()==DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN
		DisplayServer.window_set_mode(mode)
